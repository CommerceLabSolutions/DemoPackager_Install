CREATE TABLE IF NOT EXISTS `#__custom_user` (
`id` int(11) UNSIGNED NOT NULL,
`user_id` int(11) NOT NULL,
`field_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
`image_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
`created_time` datetime DEFAULT NULL
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

