DROP TABLE IF EXISTS `#__user_pro_custom_user`;
DROP TABLE IF EXISTS `#__user_pro_email_setting`;